package xyz.whoes;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class TestTimer {
	static String[] strarray;
	static SimpleDateFormat df = new SimpleDateFormat("HH:mm");
	static String token;
	public static void showTimer() {
		token = send.sendGet("http://wx.whoes.xyz/Home/wetoken", "");
	    TimerTask task = new TimerTask() {
	        @Override
	        public void run() {
	            for (int i = 0; i < strarray.length; i++){
	            	if(strarray[i].equals(df.format(new Date()))){
	            		String code = send.sendGet("http://wx.whoes.xyz/Home/sendMsg", "token="+token);
	            		if("41001".equals(code) || "42001".equals(code) || "40001".equals(code)){
	                        token = send.sendGet("http://wx.whoes.xyz/Home/wetoken", "");
	                        send.sendGet("http://wx.whoes.xyz/Home/sendMsg", "token="+token);
	            		}
	            	}
	            }
	            	
	        }
	    };
	    
	    TimerTask taskTest = new TimerTask() {
	        @Override
	        public void run() {
	            String s = send.sendGet("http://wx.whoes.xyz/Home/timeTask", "");
	            strarray = s.split(",");
	        }
	    };
	
	    //设置执行时间
	    Calendar calendar = Calendar.getInstance();
	    int year = calendar.get(Calendar.YEAR);
	    int month = calendar.get(Calendar.MONTH);
	    int day = calendar.get(Calendar.DAY_OF_MONTH);//每天
	    //定制每天的21:09:00执行，
	    calendar.set(year, month, day-1, 00, 00, 00);
	    Date date = calendar.getTime();
	    Timer timer = new Timer();
	    System.out.println(date);
	    //每天的date时刻执行task, 仅执行一次
	    timer.schedule(taskTest, date);       
	    int period = 60 * 1000;
	    //每天的date时刻执行task，每隔2秒重复执行
	    timer.schedule(task, date, period);
	}

    public static void main(String[] args) {
        showTimer();
    }
}