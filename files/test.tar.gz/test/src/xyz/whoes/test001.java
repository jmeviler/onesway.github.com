package xyz.whoes;

public class test001 {
    public static void main(String[] args) {
        String s=send.sendGet("http://wx.whoes.xyz/Home/token", "");
        System.out.println(s);
//        test001 test = new test001();
//        System.out.println(test.getToken());
    }
    public String getToken(){
        String token = send.sendGet("http://wx.whoes.xyz/Home/wetoken", null);
        System.out.println(token);
        return token;
    }
}
