package xyz.whoes;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class test002 {
//	static SimpleDateFormat df = new SimpleDateFormat("HH:mm");//设置日期格式
//	static String date = null;
	public static void main(String[] args) {
    	System.out.println("test001");
		Runnable runnable = new Runnable() {
			
			public void run() {
        	System.out.println("test002");
//				date = df.format(new Date());// new Date()为获取当前系统时间
            }
			
        };
        System.out.println("test003");
        ScheduledExecutorService service = Executors.newSingleThreadScheduledExecutor();
//        if("13:37".equals(date))
        service.scheduleAtFixedRate(runnable, 1, 3, TimeUnit.SECONDS);
		
	}

}
