package xyz.whoes;

public class test001 {
	public static void main(String[] args) {
		String s=send.sendGet("http://wx.whoes.xyz/Home/vpn", "");
        System.out.println(s);
	}
}
