$(document).ready(function(){
    showQuestionList(null, 3, 1, "ASC");

    $("#pageSizeSelected").on("change", function() {
        var orderRule = $("#currentChoosedOrder img").prop("alt");
        var pageSize = $("#pageSizeSelected option:selected").text();
        var currentPage = 1;
        var keyword = $("#keyword").val();
        showQuestionList(keyword, pageSize, currentPage, orderRule);
    });

    $(".keywordButton").on("click", function() {
        var orderRule = $("#currentChoosedOrder img").prop("alt");
        var pageSize = $("#pageSizeSelected option:selected").text();
        var currentPage = 1;
        var keyword = $("#keyword").val();
        showQuestionList(keyword, pageSize, currentPage, orderRule);
    });

    $("#pageJumpATag").hover(".gotoPage", function() {
        $(this).css("background-color", "#eee");
    });

    $("#gotoPageNum .gotoPage").on('click', function() {
        var orderRule = $("#currentChoosedOrder img").prop("alt");
        var currentPage = $("#enterPageNum").val();
        if (currentPage == null || currentPage <= 0) {
            alert("Page number must be a number and not null!");
            return false;
        }

        var pageSize = $("#pageSizeSelected option:selected").text();
        var keyword = $("keyword").val();
        showQuestionList(keyword, pageSize, currentPage, orderRule);
    });

    $("#pageJumpATag").on("click", ".gotoPage", function() {
        var orderRule = $("#currentChoosedOrder img").prop("alt");
        var pageSize = $("#pageSizeSelected option:selected").text();
        var oldPage = $("#enterPageNum").val();
        var currentPage = $(this).text();
        var allPageNum =  $("#allPageNum").text();
        var keyword = $("#keyword").val();

        if (oldPage == 1) {
            if (currentPage == "|<" || currentPage == "<") {
                return false;
            }
        } else if (oldPage == allPageNum) {
            if (currentPage == ">" || currentPage == ">|") {
                return false;
            }
        }

        if (currentPage == "|<") {
            currentPage = 1;
        } else if (currentPage == "<" ) {
            currentPage = parseInt(oldPage) - 1;
        } else if (currentPage == ">" ) {
            currentPage = parseInt(oldPage) + 1;
        } else if (currentPage == ">|"  ) {
            currentPage = allPageNum;
        } 

        for(var i = 0; i< 9;i++){
            var text = $("#pageJumpATag a:eq("+i+")").text();
            if(text == currentPage){
                $("#pageJumpATag a:eq(" + i + ")").css("background","#428bca");
                $("#pageJumpATag a:eq(" + i + ")").css("color","#fff");
                $("#pageJumpATag a:eq(" + i + ")").css("padding","2px 0 0 0");
            } else {
                $("#pageJumpATag a:eq(" + i + ")").css("background","#fff");
                $("#pageJumpATag a:eq(" + i + ")").css("color","#428bca");
                $("#pageJumpATag a:eq(" + i + ")").css("padding","2px 0 0 0");
            }
        }
        
        showQuestionList(keyword, pageSize, currentPage, orderRule);
    });

    $("#currentChoosedOrder").on('click', function() {
        var pageSize = $("#pageSizeSelected option:selected").text();
        var currentPage = 1;
        var keyword = $("#keyword").val();
        var orderRule = $("#currentChoosedOrder img").prop("alt");
        console.log(orderRule);

        if (orderRule == "ASC") {
            $("#currentChoosedOrder img").prop("alt", "DESC");
            $("#currentChoosedOrder img").prop("src", "picture/sort-desc-active.png");
            orderRule = "DESC";
        } else if (orderRule == "DESC") {
            $("#currentChoosedOrder img").prop("alt", "ASC");
            $("#currentChoosedOrder img").prop("src", "picture/sort-asc-active.png");
            orderRule = "ASC";
        }
        
        
        console.log(orderRule);
        showQuestionList(keyword, pageSize, currentPage, orderRule);
    });
}); 

function showQuestionList(keyword, pageSize, currentPage, orderRule){
    $.ajax({
        type:"GET",
        url:"question/view",
        dataType:"json",
        data:{"pageSize" : pageSize, "currentPage" : currentPage, "keyword" : keyword, "orderRule" : orderRule},
        success:function(data){
            var que = "";
            var questions = data.question;
            var allPageNum = data.allPagesNum;
            $("#showResult").empty();
            for ( var i = 0; i < questions.length; i++) {
                var id = (currentPage - 1) * pageSize + i + 1;
                que += "<tr>";
                que += "<td class='questionId'>" + id + "</td>";
                que += "<td class='questionDesc'>" + questions[i].description + "</td>";
                que += "<td class='questionAnswer'>" + questions[i].answer + "</td>";
                que += "<td class='operation'><a class='common' href='#'>Edit</a>&nbsp;&nbsp;"
                    + "<a class='common' href='#'>Delete</a></td>";
                que+="</tr>";
            }
            $("#showResult").append(que);
            $("#enterPageNum").val(currentPage);
            $("#allPageNum").text(allPageNum);
            
            printPageNumber(currentPage, allPageNum);
        }
     });
}

function printPageNumber(currentPage, allPageNum) {
    var pageList = "";
    $("#pageJumpATag").empty();
    pageList += "<a class='gotoPage' style='padding: 2px 0px 0px;'>|&lt;</a>";
    pageList += "<a class='gotoPage' style='padding: 2px 0px 0px;'>&lt;</a>";
    if (allPageNum <= 5) {
        for ( var i = 1; i <= allPageNum ; i++) {
            pageList += "<a class='gotoPage' style='padding: 2px 0px 0px;'>" + i + "</a>";
        }
    } else if (currentPage <= 3) {
        for ( var i = 1; i <= 5 ; i++) {
            pageList += "<a class='gotoPage' style='padding: 2px 0px 0px;'>" + i + "</a>";
        }
    } else if (currentPage <= allPageNum - 2) {
        for ( var i = currentPage - 2; i <= parseInt(currentPage) + 2; i++) {
            pageList += "<a class='gotoPage' style='padding: 2px 0px 0px;'>" + i + "</a>";
        }
    } else if (currentPage <= allPageNum && currentPage >= allPageNum - 2) {
        for ( var i = currentPage - 2; i <= allPageNum; i++) {
            pageList += "<a class='gotoPage' style='padding: 2px 0px 0px;'>" + i + "</a>";
        }
    }
    pageList += "<a class='gotoPage' style='padding: 2px 0px 0px;'>&gt;</a>";
    pageList += "<a class='gotoPage' style='padding: 2px 0px 0px;'>&gt;|</a>";
    $("#pageJumpATag").append(pageList);
    
    if (currentPage == 1) {
        $("#pageJumpATag a:eq(0)").css("cursor","not-allowed");
        $("#pageJumpATag a:eq(1)").css("cursor","not-allowed");
    } else if (currentPage == allPageNum) {
        for(var i = 0; i< 9;i++){
            var text = $("#pageJumpATag a:eq("+i+")").text();
            if (text == ">" || text == ">|") {
                $("#pageJumpATag a:eq(" + i + ")").css("cursor","not-allowed");
                $("#pageJumpATag a:eq(" + i + ")").css("cursor","not-allowed");
            }
        }
    }
    
    for(var i = 0; i< 9;i++){
        var text = $("#pageJumpATag a:eq("+i+")").text();
        if(text == currentPage){
            $("#pageJumpATag a:eq(" + i + ")").css("background","#428bca");
            $("#pageJumpATag a:eq(" + i + ")").css("color","#fff");
        } else {
            $("#pageJumpATag a:eq(" + i + ")").css("background","#fff");
            $("#pageJumpATag a:eq(" + i + ")").css("color","#428bca");
        }
    }
}

