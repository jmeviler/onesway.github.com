package com.augmentum.service;

import java.util.List;

import com.augmentum.common.exception.ServiceException;
import com.augmentum.pojo.model.Question;

public interface QuestionService {

    public void addQuestion(Question question) throws ServiceException;

    public void deleteQuestionById(int id) throws ServiceException;

    public void updateQuestion(Question question) throws ServiceException;

    public Question selectQuestionById(int id) throws ServiceException;

    public List<Question> selectQuestions(String keywords, int pageNum, int pageSize, String orderRule) throws ServiceException;

    public int countByKeyword(String keyword) throws ServiceException;

}
