package com.augmentum.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.augmentum.common.exception.ExceptionMessage;
import com.augmentum.common.exception.ServiceException;
import com.augmentum.dao.QuestionMapper;
import com.augmentum.pojo.model.Question;
import com.augmentum.service.QuestionService;

@Service
public class QuestionServiceImpl implements QuestionService{

    @Autowired
    private QuestionMapper questionMapper;

    @Override
    public void addQuestion(Question question) throws ServiceException {
        try {
            if (!questionMapper.add(question)) {
                throw new ServiceException(ExceptionMessage.QUESTION_ADD_FAILED);
            }
        } catch (Exception e) {
            throw new ServiceException(ExceptionMessage.QUESTION_ADD_FAILED, e);
        }
    }

    @Override
    public int countByKeyword(String keyword) throws ServiceException {
        int count = 0;

        try {
            count = questionMapper.countByKeyword(keyword);
            if (count == 0) {
                throw new ServiceException(ExceptionMessage.QUESTION_NOT_FOUND);
            }
        } catch (Exception e) {
            throw new ServiceException(ExceptionMessage.QUESTION_NOT_FOUND, e);
        }

        return count;
    }

    @Override
    public void deleteQuestionById(int id) throws ServiceException {
        try {
            if (!questionMapper.deleteById(id)) {
                throw new ServiceException(ExceptionMessage.QUESTION_DELETE_FAILED);
            }
        } catch (Exception e) {
            throw new ServiceException(ExceptionMessage.QUESTION_DELETE_FAILED, e);
        }
    }

    @Override
    public Question selectQuestionById(int id) throws ServiceException {
        Question question = null;

        try {
            if ((question = questionMapper.getById(id)) == null) {
                throw new ServiceException(ExceptionMessage.QUESTION_NOT_FOUND);
            }
        } catch (Exception e) {
            throw new ServiceException(ExceptionMessage.QUESTION_NOT_FOUND, e);
        }

        return question;
    }

    @Override
    public List<Question> selectQuestions(String keywords, int pageNum,
            int pageSize, String orderRule) throws ServiceException {
        List<Question> questionList = new ArrayList<Question>();

        try {
            int startNum = (pageNum - 1) * pageSize;
            questionList = questionMapper.getByKeyword(keywords, startNum, pageSize, orderRule);

            if (questionList == null) {
                throw new ServiceException(ExceptionMessage.QUESTION_NOT_FOUND);
            }
        } catch (Exception e) {
            throw new ServiceException(ExceptionMessage.QUESTION_NOT_FOUND, e);
        }

        return questionList;
    }

    @Override
    public void updateQuestion(Question question) throws ServiceException {
        try {
            if (!questionMapper.updateQuestion(question)) {
                throw new ServiceException(ExceptionMessage.QUESTION_UPDATE_FAILED);
            }
        } catch (Exception e) {
            throw new ServiceException(ExceptionMessage.QUESTION_UPDATE_FAILED, e);
        }
    }
}
