package com.augmentum.common;

public class Constant {
    public final static String URL = "url";
    public final static String TYPE = "type";
    public final static String USER = "user";
    public final static String QUESTION = "question";
    public final static String MESSAGE = "messageFromServlet";

    public final static String INDEX = "index";
    public final static String USER_ADD = "userAdd";
    public final static String USER_EDIT = "userEdit";
    public final static String USER_VIEW = "userView";
    public final static String QUES_ADD = "questionAdd";
    public final static String QUES_EDIT = "questionEdit";
    public final static String QUES_VIEW = "questionView";
    public final static String EXAM_ADD = "examAdd";
    public final static String EXAM_VIEW = "examView";
    public final static String HOME = "home";
    public final static String WELCOME = "welcome";
    public final static String PROFILE_EDIT = "profileEdit";

    public final static String EMAIL_ADDRESS = "@augmentum.com.cn";

    public final static String ROLE_SYSTEM = "SystemAdmin";
    public final static String ROLE_CONTENT = "ContentAdmin";
    public final static String ROLE_TEACHER = "Teacher";
    public final static String ROLE_STUDENT = "Student";
    public final static String GENDER_MALE = "Male";
    public final static String GENDER_FEMALE = "Female";
    public final static String GENDER_UNKNOW = "Unknow";

    public final static String SUCCESS_MESSAGE = "The success of the operation!";
    public final static String FAILED_MESSAGE = "The operation failed!";

}
