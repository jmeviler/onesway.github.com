package com.augmentum.common;

public class KeywordBuilder {
    public static String builtKeyword(String keyword) {

        if (keyword == null || keyword.equals("")) {
            keyword = "%";
        } else {
            StringBuilder keywordBuilder = null;
            char[] charArray = keyword.toCharArray();
            keywordBuilder= new StringBuilder();
            keywordBuilder.append('%');

            for (int i = 0; i < charArray.length; i++) {
                if (charArray[i] == '%' || charArray[i] == '_') {
                    keywordBuilder.append('\\');
                }
                keywordBuilder.append(charArray[i]);
            }

            keywordBuilder.append('%');
            keyword = new String(keywordBuilder);
        }

        return keyword;
    }
}
