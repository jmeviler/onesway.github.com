package com.augmentum.common.exception;

public class ExceptionMessage {
    /*
     * User
     */
    public final static String USER_NOT_FOUND = "User was not found!";
    public final static String USER_ADD_FAILED = "User add failed!";
    public final static String USER_SET_ROLE_FAILED = "User's role set failed!";
    public final static String USER_DELETE_FAILED = "User deleted failed!";
    public final static String USER_UPDATE_MESSAGE_FAILED = "User's message updated failed!";
    public final static String USER_UPDATE_ROLE_FAILED = "User's role change failed!";
    public final static String USER_DELETE_SUCCESS = "User deleted successfully!!";

    /*
     * Question
     */
    public final static String QUESTION_NOT_FOUND = "Question was not found!";
    public final static String QUESTION_ADD_FAILED = "Question add failed!";
    public final static String QUESTION_DELETE_FAILED = "Question delete failed!";
    public final static String QUESTION_UPDATE_FAILED = "Question update failed!";

}
