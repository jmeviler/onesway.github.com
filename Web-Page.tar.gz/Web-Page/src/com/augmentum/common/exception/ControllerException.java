package com.augmentum.common.exception;

public class ControllerException extends Exception{

    private static final long serialVersionUID = -2238997306471106981L;
    private int exceptionCode;
    private String message;

    public int getExceptionCode() {
        return exceptionCode;
    }

    @Override
    public String getMessage() {
        return message;
    }

    public ControllerException() {
        super();
    }

    public ControllerException(int exceptionCode, String message) {
        this.exceptionCode = exceptionCode;
        this.message = message;
    }

    public ControllerException(String message, Throwable cause) {
        super(message, cause);
    }

    public ControllerException(String message) {
        super(message);
    }

    public ControllerException(Throwable cause) {
        super(cause);
    }


}
