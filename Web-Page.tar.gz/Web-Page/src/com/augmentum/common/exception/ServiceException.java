package com.augmentum.common.exception;

import org.apache.log4j.Logger;

public class ServiceException extends Exception{

    private static final long serialVersionUID = -2627729237339087157L;
    private static final Logger LOGGER = Logger.getLogger(Logger.class);

    private String message;

    public ServiceException() {
        super();
        LOGGER.error(message);
    }

    public ServiceException(String message, Throwable cause) {
        super(message, cause);
        LOGGER.error(message);
        LOGGER.debug(cause);
    }

    public ServiceException(String message) {
        this.message = message;
        LOGGER.error(message);
    }

    public ServiceException(Throwable cause) {
        super(cause);
        LOGGER.error(message, cause);
    }

    @Override
    public String getMessage() {
        return message;
    }


}
