package com.augmentum.common;

public class DataValidation {
    public static boolean checkLength(String str, int maxLength){
        boolean isOk = true;

        if (str.length() > maxLength) {
            isOk = false;
        }

        return isOk;
    }

    public static boolean isNumber(String str) {
        boolean isOk = true;

        char[] charArray = str.toCharArray();
        for (int i = 0; i < charArray.length; i++) {
            if (charArray[i] > '9' || charArray[i] < '0') {
                isOk = false;
            }
        }
        return isOk;
    }
}
