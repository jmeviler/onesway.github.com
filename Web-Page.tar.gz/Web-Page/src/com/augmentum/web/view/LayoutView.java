package com.augmentum.web.view;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.JstlView;

import com.augmentum.common.Constant;

public class LayoutView extends JstlView {

    @Override
    protected void renderMergedOutputModel(Map<String, Object> model,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        this.exposeModelAsRequestAttributes(model, request);
        String dispatcherPath = this.prepareForRendering(request, response);
        request.setAttribute(Constant.URL, dispatcherPath);
        request.getRequestDispatcher("/WEB-INF/common/welcome.jsp")
            .forward(request, response);
    }

}
