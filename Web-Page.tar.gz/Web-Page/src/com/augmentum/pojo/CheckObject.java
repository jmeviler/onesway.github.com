package com.augmentum.pojo;

import com.augmentum.common.DataValidation;
import com.augmentum.pojo.model.Question;


public class CheckObject {
    public static boolean checkQuestion(Question question) {
        if (question == null || question.getId() < 0
            || question.getDescription() == null
            || question.getAnswer() == null || question.getOptionA() == null
            || question.getOptionB() == null || question.getOptionC() == null
            || question.getOptionD() == null ) {
            return true;
        }

        if (!DataValidation.checkLength(question.getDescription(), 256)
                || !DataValidation.checkLength(question.getAnswer(), 2)
                || !DataValidation.checkLength(question.getOptionA(), 128)
                || !DataValidation.checkLength(question.getOptionB(), 128)
                || !DataValidation.checkLength(question.getOptionC(), 128)
                || !DataValidation.checkLength(question.getOptionD(), 128)) {
            return true;
        }

        return false;

    }

/*  public static boolean checkUser(User user) {
        if (user == null || user.getName() == null || !DataValidation.checkLength(user.getName(), 25)) {
            return true;
        } else if (user.getPassword() != null
                && !DataValidation.checkLength(user.getPassword(), 41)) {
            return true;
        } else if (user.getChineseName() != null
                && !DataValidation.checkLength(user.getChineseName(), 30)) {
            return true;
        } else if (user.getPhone() != null
                && !DataValidation.checkLength(user.getPhone(), 30)) {
            return true;
        } else if (user.getMail() != null
                && DataValidation.checkLength(user.getMail(), 4)) {
            return true;
        } else {
            return false;
        }
    }

    public static boolean checkRole(Role role) {
        if (role == null) {
            return true;
        } else if ( role.getId() < 0 ) {
            return true;
        } else if (role.getRoleName() == null || role.getRoleType() == null) {
            return true;
        } else if (!DataValidation.checkLength(role.getRoleName(), 64)) {
            return true;
        } else if (!DataValidation.checkLength(role.getRoleType(), 20)) {
            return true;
        } else {
            return false;
        }
    }
*/
}
