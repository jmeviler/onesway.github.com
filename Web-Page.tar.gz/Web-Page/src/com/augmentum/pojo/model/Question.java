package com.augmentum.pojo.model;


public class Question {
    private int id;
    private String description;
    private boolean used;
    private boolean changed;
    private boolean deleted;
    private String optionA;
    private String optionB;
    private String optionC;
    private String optionD;
    private String answer;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isUsed() {
        return used;
    }

    public void setUsed(boolean used) {
        this.used = used;
    }

    public boolean isChanged() {
        return changed;
    }

    public void setChanged(boolean changed) {
        this.changed = changed;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public String getOptionA() {
        return optionA;
    }

    public void setOptionA(String optionA) {
        this.optionA = optionA;
    }

    public String getOptionB() {
        return optionB;
    }

    public void setOptionB(String optionB) {
        this.optionB = optionB;
    }

    public String getOptionC() {
        return optionC;
    }

    public void setOptionC(String optionC) {
        this.optionC = optionC;
    }

    public String getOptionD() {
        return optionD;
    }

    public void setOptionD(String optionD) {
        this.optionD = optionD;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    @Override
    public String toString() {
        return "Question [id=" + id + ", description=" + description
                + "\n deleted=" + deleted + ", used=" + used
                + ", changed=" + changed + "\n optionA=" + optionA + "\n optionB="
                + optionB + "\n optionC=" + optionC + "\n optionD=" + optionD
                + "\n answer=" + answer + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((answer == null) ? 0 : answer.hashCode());
        result = prime * result + (changed ? 1231 : 1237);
        result = prime * result + (deleted ? 1231 : 1237);
        result = prime * result
                + ((description == null) ? 0 : description.hashCode());
        result = prime * result + id;
        result = prime * result + ((optionA == null) ? 0 : optionA.hashCode());
        result = prime * result + ((optionB == null) ? 0 : optionB.hashCode());
        result = prime * result + ((optionC == null) ? 0 : optionC.hashCode());
        result = prime * result + ((optionD == null) ? 0 : optionD.hashCode());
        result = prime * result + (used ? 1231 : 1237);
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Question other = (Question) obj;
        if (answer == null) {
            if (other.answer != null) {
                return false;
            }
        } else if (!answer.equals(other.answer)) {
            return false;
        }
        if (changed != other.changed) {
            return false;
        }
        if (deleted != other.deleted) {
            return false;
        }
        if (description == null) {
            if (other.description != null) {
                return false;
            }
        } else if (!description.equals(other.description)) {
            return false;
        }
        if (id != other.id) {
            return false;
        }
        if (optionA == null) {
            if (other.optionA != null) {
                return false;
            }
        } else if (!optionA.equals(other.optionA)) {
            return false;
        }
        if (optionB == null) {
            if (other.optionB != null) {
                return false;
            }
        } else if (!optionB.equals(other.optionB)) {
            return false;
        }
        if (optionC == null) {
            if (other.optionC != null) {
                return false;
            }
        } else if (!optionC.equals(other.optionC)) {
            return false;
        }
        if (optionD == null) {
            if (other.optionD != null) {
                return false;
            }
        } else if (!optionD.equals(other.optionD)) {
            return false;
        }
        if (used != other.used) {
            return false;
        }
        return true;
    }

}
