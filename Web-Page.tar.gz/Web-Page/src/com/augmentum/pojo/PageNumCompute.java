package com.augmentum.pojo;

import com.augmentum.common.DataValidation;


public class PageNumCompute {
    public static int getPageNum(String str, int allPagesNum) {
        int pageNum = 1;

        if (str == null ) {
            pageNum = 1;
        } else {
            if (!DataValidation.isNumber(str)) {
                pageNum = 1;
            } else {
                pageNum = Integer.parseInt(str);

                if (pageNum < 1) {
                    pageNum = 1;
                } else if (pageNum > allPagesNum) {
                    pageNum = allPagesNum;
                }
            }
        }


        return pageNum;
    }
}
