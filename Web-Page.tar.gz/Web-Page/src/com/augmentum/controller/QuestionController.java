package com.augmentum.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.augmentum.common.Constant;
import com.augmentum.common.KeywordBuilder;
import com.augmentum.common.exception.ServiceException;
import com.augmentum.pojo.PageNumCompute;
import com.augmentum.pojo.model.Question;
import com.augmentum.service.QuestionService;

@Controller
@RequestMapping(value = "question")
public class QuestionController {

    @Autowired
    private QuestionService questionService;

    @RequestMapping(value = "view", method = {RequestMethod.GET})
    @ResponseBody
    public Map<String,Object> viewQuestion(
            @RequestParam(value = "keyword", required = false) String keyword,
            @RequestParam(value = "pageSize", required = false) String getPageSize,
            @RequestParam(value = "currentPage", required = false) String getCurrentPage,
            @RequestParam(value = "orderRule") String orderRule) {

        Map<String, Object> map = new HashMap<String, Object>();
        String keywords = KeywordBuilder.builtKeyword(keyword);
        int pageSize;
        int allPagesNum;

        if (getPageSize == null) {
            pageSize = 10;
        } else {
            pageSize = Integer.parseInt(getPageSize);
        }

        try {
            int count = questionService.countByKeyword(keywords);
            if (count%pageSize == 0) {
                allPagesNum = count/pageSize;
            } else {
                allPagesNum = count/pageSize + 1;
            }

            int currentPage = PageNumCompute.getPageNum(getCurrentPage, allPagesNum);
            List<Question> questionList = questionService
                .selectQuestions(keywords, currentPage, pageSize, orderRule);
            map.put(Constant.QUESTION, questionList);
            map.put("allPagesNum", allPagesNum);
        } catch (ServiceException e) {
        }

        return map;
    }

/*  @RequestMapping(value = "add", method = {RequestMethod.POST})
    public ModelAndView addQuestion(@RequestParam("description") String QuestionDesc,
            @RequestParam("answer") String answer,
            @RequestParam("optionA") String optionA,
            @RequestParam("optionA") String optionB,
            @RequestParam("optionA") String optionC,
            @RequestParam("optionA") String optionD) {
        ModelAndView mav = new ModelAndView();
        Question question = new Question();
        question.setDescription(QuestionDesc);
        question.setOptionA(optionA);
        question.setOptionB(optionB);
        question.setOptionC(optionC);
        question.setOptionD(optionD);
        question.setAnswer(answer);

        if (QuestionDesc == null || answer == null || optionA == null
                || optionB == null || optionC == null || optionD == null) {
            mav.addObject(Constant.MESSAGE, "Question description, "
                    + "answer, optionA, optionB, optionC and optionD "
                    + "all of them are not null");
            mav.addObject(Constant.QUESTION, question);
            mav.setViewName(Constant.QUES_ADD);
            return mav;
        }

        try {
            questionService.addQuestion(question);
            mav.addObject(Constant.MESSAGE, "Question saved successfully!");
        } catch (ServiceException e) {
            mav.addObject(Constant.MESSAGE, "Question saved failed!");
            mav.addObject(Constant.QUESTION, question);
        }

        mav.setViewName(Constant.HOME);
        return mav;
    }

    @RequestMapping(value = "delete", method = {RequestMethod.GET})
    public ModelAndView deleteQuestion(@RequestParam("id") int id) {
        ModelAndView mav = new ModelAndView();

        try {
            questionService.deleteQuestionById(id);
            mav.addObject(Constant.MESSAGE, "Question delete successfully!");
        } catch (ServiceException e) {
            mav.addObject(Constant.MESSAGE, "Question delete failed!");
        }

        mav.setViewName(Constant.HOME);
        return mav;
    }

    @RequestMapping(value = "edit", method = {RequestMethod.POST})
    public ModelAndView updateQuestion(@RequestParam("id") int questionId,
            @RequestParam("description") String questionDesc,
            @RequestParam("answer") String answer,
            @RequestParam("optionA") String optionA,
            @RequestParam("optionA") String optionB,
            @RequestParam("optionA") String optionC,
            @RequestParam("optionA") String optionD) {
        ModelAndView mav = new ModelAndView();
        Question question = null;

        try {
            question = questionService.selectQuestionById(questionId);
        } catch (ServiceException e) {
            mav.addObject(Constant.MESSAGE, "Question was not found!");
            mav.setViewName(Constant.HOME);
            return mav;
        }

        question.setDescription(questionDesc);
        question.setOptionA(optionA);
        question.setOptionB(optionB);
        question.setOptionC(optionC);
        question.setOptionD(optionD);
        question.setAnswer(answer);

        if ( questionDesc == null || answer == null || optionA == null
                || optionB == null || optionC == null || optionD == null) {
            mav.addObject(Constant.MESSAGE, "Question description, "
                    + "answer, optionA, optionB, optionC and optionD "
                    + "all of them are not null");
            mav.addObject(Constant.QUESTION, question);
            mav.setViewName(Constant.QUES_ADD);
            return mav;
        }

        try {
            questionService.updateQuestion(question);
            mav.addObject(Constant.MESSAGE, "Question update successfully!");
            mav.setViewName(Constant.HOME);
        } catch (ServiceException e) {
            mav.addObject(Constant.MESSAGE, "Question update failed!");
            mav.setViewName(Constant.HOME);
        }

        return mav;
    }
*/
}
