package com.augmentum.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.augmentum.pojo.model.Question;

@Repository
public interface QuestionMapper {

    public boolean add(Question question);

    public boolean deleteById(@Param(value = "id") int id);

    public boolean updateQuestion(Question question);

    public Question getById(@Param("id") int id);

    public List<Question> getByKeyword(@Param("keyword")String keyword,
            @Param("startNum")int startNum, @Param("size")int size, @Param("orderRule") String orderRule);

    public int countByKeyword(@Param("keyword") String keyword);

}
